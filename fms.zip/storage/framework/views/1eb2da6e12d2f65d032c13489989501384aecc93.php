<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor">Fixture Results</h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">Fixture Results</li>
            </ol>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
<div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Goal Scorers</h4>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th style="width:10%">#</th>
                                <th style="width:20%">Player</th>
                                <th style="width:50%">Name</th>
                                <th style="width:20%">Goals Scored</th>
                            </tr>
                        </thead>
                            <tbody><?php $__currentLoopData = $goal_scorers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $goal_scorer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
								<td><img class="img profile-pic-coach" src="<?php echo e(asset($goal_scorer->player->photo)); ?>" /></td>
								<td><?php echo e($goal_scorer->player->name); ?></td>
                                <td><?php echo e($goal_scorer->goals_scored); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                        </tbody>
                    </table>
                </div>
              
                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Assists</h4>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th style="width:10%">#</th>
                                <th style="width:20%">Player</th>
                                <th style="width:50%">Name</th>
                                <th style="width:20%">Assists</th>
                            </tr>
                        </thead>
                            <tbody><?php $__currentLoopData = $assists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $assist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
								<td><img class="img profile-pic-coach" src="<?php echo e(asset($assist->player->photo)); ?>" /></td>
								<td><?php echo e($assist->player->name); ?></td>
                                <td><?php echo e($assist->assists); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                        </tbody>
                    </table>
                </div>

                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Yellow Cards</h4>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th style="width:10%">#</th>
                                <th style="width:20%">Player</th>
                                <th style="width:50%">Name</th>
                                <th style="width:20%">Yellow Cards</th>
                            </tr>
                        </thead>
                            <tbody><?php $__currentLoopData = $yellow_cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $yellow_card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
								<td><img class="img profile-pic-coach" src="<?php echo e(asset($yellow_card->player->photo)); ?>" /></td>
								<td><?php echo e($yellow_card->player->name); ?></td>
                                <td><?php echo e($yellow_card->yellow_cards); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                        </tbody>
                    </table>
                </div>
                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Red Cards</h4>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th style="width:10%">#</th>
                                <th style="width:20%">Player</th>
                                <th style="width:50%">Name</th>
                                <th style="width:20%">Red Cards</th>
                            </tr>
                        </thead>
                            <tbody><?php $__currentLoopData = $red_cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $red_card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
								<td><img class="img profile-pic-coach" src="<?php echo e(asset($red_card->player->photo)); ?>" /></td>
								<td><?php echo e($red_card->player->name); ?></td>
                                <td><?php echo e($red_card->red_cards); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                        </tbody>
                    </table>
                </div>
              
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\upwork\fms\resources\views/admin/fixtures/results.blade.php ENDPATH**/ ?>