<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor">Coaches</h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                
            </ol>
			<?php if(Auth::user()->role==1): ?>
            <a href="<?php echo e(route('new.coach')); ?>" class="btn btn-primary d-none d-lg-block m-l-15"> Add New Coach</a>
			<?php endif; ?>
		</div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
<div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Coaches</h4>
                    </div>
                </div>
                <?php echo $__env->make('pages.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Contact</th>
                                <th>Team</th>
                                <th>Squad</th>
                                <th>DOB</th>
                                <th>Gender</th>
								<?php if(Auth::user()->role==1): ?>
                                <th>Actions</th>
								<?php endif; ?>
                            </tr>
                        </thead>
                            <tbody><?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
								<td><img class="img img-responsive profile-pic-coach" src="<?php echo e(asset($coach->profile_photo_path)); ?>" /></td>
								<td><?php echo e($coach->name); ?></td>
                                <td><?php echo e($coach->username); ?></td>
                                <td><?php echo e($coach->email); ?></td>
                                <td><?php echo e($coach->address); ?></td>
                                <td style="white-space: nowrap"><?php echo e($coach->phone); ?></td>
                                <td style="white-space: nowrap"><?php echo e(\App\Models\Teams::find($coach->current_team_id)->name); ?> </td>
                                <td><?php echo e(\App\Models\Squad::find($coach->current_squad_id)->name); ?> </td>
                                <td style="white-space: nowrap"><?php echo e($coach->dob); ?></td>
                                <td><?php echo e($coach->gender); ?></td>
								<?php if(Auth::user()->role==1): ?>
								<td style="white-space: nowrap">
									<a href="<?php echo e(route('edit.coach',$coach->id)); ?>" class="btn btn-primary">Edit</a>
									<a href="<?php echo e(route('delete.coach',$coach->id)); ?>" class="btn btn-danger" id="delete" onclick="return confirm('Are you sure you want to delete this coach?');"> Delete</a>
								</td>
								<?php endif; ?>
							</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\upwork\fms\resources\views/admin/coaches/coach_registration/view_coaches.blade.php ENDPATH**/ ?>