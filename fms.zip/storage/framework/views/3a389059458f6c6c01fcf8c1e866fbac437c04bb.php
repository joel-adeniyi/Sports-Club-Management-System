

<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor">Player Statistics</h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('view.player')); ?>">Players</a></li>
                <li class="breadcrumb-item active">Player Statistics</li>
            </ol>
            <!-- <a href="/" class="btn btn-success d-none d-lg-block m-l-15"> Dashboard</a> -->
        </div>
    </div>
</div>


<!-- Page Content -->

<div class="row">
<div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex no-block align-items-center">
                    <div class="player_img">
                        <h4 class="card-title my-2"><?php echo e($player->name); ?></h4>
                        <img src="<?php echo e(asset($player->photo)); ?>" alt="player" class="img img-responsive player-img">
                    </div>
                </div>
                <div class="d-flex no-block align-items-center my-3">
                    <div>
                        <h4 class="card-title">Player Statistics</h4>
                        
                    </div>
                    
                </div>
                <?php echo $__env->make('pages.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-12">
                    <form class="form" method="post" action="<?php echo e(route('update.statistic',$player->statistic->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-4">
                                <label for="goals_scored" class="col-form-label">Goals Scored</label>
                                <div class="controls">
                                    <input type="number" name="goals_scored" value="<?php echo e($player->statistic->goals_scored); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['goals_scored'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="goals_conceded" class="col-form-label">Goals Conceded</label>
                                <div class="controls">
                                    <input type="number" name="goals_conceded" value="<?php echo e($player->statistic->goals_conceded); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['goals_conceded'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="assists" class="col-form-label">Assists</label>
                                <div class="controls">
                                    <input type="number" name="assists" value="<?php echo e($player->statistic->assists); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['assists'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="games_played" class="col-form-label">Games Played</label>
                                <div class="controls">
                                    <input type="number" name="games_played" value="<?php echo e($player->statistic->games_played); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['games_played'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="shots_taken" class="col-form-label">Shots Taken</label>
                                <div class="controls">
                                    <input type="number" name="shots_taken" value="<?php echo e($player->statistic->shots_taken); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['shots_taken'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="shots_missed" class="col-form-label">Shots Missed</label>
                                <div class="controls">
                                    <input type="number" name="shots_missed" value="<?php echo e($player->statistic->shots_missed); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['shots_missed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="minutes_played" class="col-form-label">Minutes Played</label>
                                <div class="controls">
                                    <input type="number" name="minutes_played" value="<?php echo e($player->statistic->minutes_played); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['minutes_played'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="red_cards" class="col-form-label">Red Cards</label>
                                <div class="controls">
                                    <input type="number" name="red_cards" value="<?php echo e($player->statistic->red_cards); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['red_cards'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="yellow_cards" class="col-form-label">Yellow Cards</label>
                                <div class="controls">
                                    <input type="number" name="yellow_cards" value="<?php echo e($player->statistic->yellow_cards); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['yellow_cards'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                                  
                            <div class=" mt-3 d-grid gap-2   col-10 col-sm-6 col-md-4 col-lg-4 col-xl-3 col-xxl-2 mx-auto  mx-sm-0">
                                <input class="btn btn-primary" type="submit" value="Update" />
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8\fms\resources\views/admin/players/statistics.blade.php ENDPATH**/ ?>