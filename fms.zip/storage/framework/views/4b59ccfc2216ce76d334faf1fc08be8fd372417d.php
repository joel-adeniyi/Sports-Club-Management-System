<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor">Add Scores</h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('fixture.index')); ?>">Fixtures</a></li>
                <li class="breadcrumb-item active">Add Scores</li>
            </ol>
            <!-- <a href="/" class="btn btn-success d-none d-lg-block m-l-15"> Dashboard</a> -->
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
    <?php if($num_players==0): ?>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Number of players</h4>
                        <h6 class="card-subtitle"> Enter number of players and fill in the scores</h6>
                    </div>
                    
                </div>
                <?php echo $__env->make('pages.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-12">
                    <form class="form" method="post" action="<?php echo e(route('add.scores.post', ['fixture' => $fixture->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-md-6">
                                <label for="result" class="col-form-label">Result <span class="text-danger">*</span></label>
                                <div class="controls">
                                    <input type="text" name="result" class="form-control" required>
                                    <?php $__errorArgs = ['result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                                
                            <div class="col-md-6">
                                <label for="outcome" class="col-form-label">Outcome <span class="text-danger">*</span></label>
                                <div class="controls">
                                    <select name="outcome" id="outcome" class="form-control">
                                        <option value="" disabled>Select Outcome</option>
                                        <option value="Win">Win</option>
                                        <option value="Draw">Draw</option>
                                        <option value="Loss">Loss</option>
                                    </select>    
                                    <?php $__errorArgs = ['outcome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="num_players" class="col-form-label">Number of players <span class="text-danger">*</span></label>
                                <div class="controls">
                                    <input type="number" min="0" oninput="this.value = Math.abs(this.value)" name="num_players" value="<?php echo e($fixture->num_players); ?>" class="form-control" required>
                                    <?php $__errorArgs = ['num_players'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                           
                        </div>
                        <div class=" mt-3 d-grid gap-2   col-10 col-sm-6 col-md-4 col-lg-4 col-xl-3 col-xxl-2 mx-auto  mx-sm-0">
                                <input class="btn btn-primary" type="submit" value="Submit" />
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if($num_players>0): ?>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Add Scores</h4>
                        <h6 class="card-subtitle"> Fill in the scores and click Add</h6>
                    </div>
                    
                </div>
                <?php echo $__env->make('pages.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-12">
                    <form class="form" method="post" action="<?php echo e(route('update.scores', ['fixture' => $fixture->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php for($i=0;$i<$num_players;$i++): ?>
                            <div class="row">
                                
                                <div class="col-md-4">
                                    <label class="col-form-label">Player<span class="text-danger">*</span></label>
                                    <div class="controls">
                                        <select name="player[]" required="" class="form-control">
                                            <option value="" selected="" disabled="">Select Player</option>
                                            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($player->id); ?>"><?php echo e($player->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <label class="col-form-label">Score <span class="text-danger">*</span></label>
                                    <div class="controls">
                                        <input type="number" min="0" oninput="this.value = Math.abs(this.value)" name="score[]" value="0" class="form-control" required>
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <label class="col-form-label">Assists <span class="text-danger">*</span></label>
                                    <div class="controls">
                                        <input type="number" min="0" oninput="this.value = Math.abs(this.value)" name="assists[]" value="0" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <label class="col-form-label">Yellow Cards <span class="text-danger">*</span></label>
                                    <div class="controls">
                                        <input type="number" min="0" oninput="this.value = Math.abs(this.value)" name="yellow_cards[]" value="0" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <label class="col-form-label">Red Cards <span class="text-danger">*</span></label>
                                    <div class="controls">
                                        <input type="number" min="0" oninput="this.value = Math.abs(this.value)" name="red_cards[]" value="0" class="form-control" required>
                                    </div>
                                </div>


                            </div>
                        <?php endfor; ?>
                        <div class=" mt-3 d-grid gap-2   col-10 col-sm-6 col-md-4 col-lg-4 col-xl-3 col-xxl-2 mx-auto  mx-sm-0">
                                <input class="btn btn-primary" type="submit" value="Submit" />
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\upwork\fms\resources\views/admin/fixtures/add_scores.blade.php ENDPATH**/ ?>