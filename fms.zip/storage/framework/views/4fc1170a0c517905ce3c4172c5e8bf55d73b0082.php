<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex,nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title> Westminster F.C. Management System</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/main/favicon.png')); ?>">

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!----css3---->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
 
</head>

<body>
    <div class=" container-fluid ">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel8\fms\resources\views/layouts/web.blade.php ENDPATH**/ ?>