<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor">Home</h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            
            
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="banner-section mb-5">
                    <!--<img src="<?php echo e(asset('images/adminPanel/banner.jpg')); ?>" alt="banner" class="img-responsive img img-banner">-->
                    <h3 class="card-title text-center mt-3">Welcome to the Football Management System</h3>
                </div>
                <div class="d-flex no-block align-items-center">
                    <div>
                        <?php if($fixtures->count()>0): ?>
                        <h4 class="card-title">Fixtures and Events</h4>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="row mb-5">
                    <?php $__currentLoopData = $fixtures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fixture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a <?php if($fixture->result && $fixture->outcome): ?>
                            href="<?php echo e(route('fixture.show', $fixture->id)); ?>"
                            <?php endif; ?> 
                            class="fixture-card col-md-4">
                            <div class="card shadow rounded mb-2">
                                <div class="card-body ">
                                    <div class="row">
                                        <div class="col-2">
                                            <h4 class="card-title"><?php echo e(date("d", strtotime($fixture->date))); ?></h4>
                                            <h6 class="card-subtitle mb-0"> <?php echo e(date("M", strtotime($fixture->date))); ?> </h6>
                                        </div>
                                        <div class="
                                        <?php if($fixture->result && $fixture->outcome): ?>
                                        col-8
                                        <?php else: ?>
                                        col-10
                                        <?php endif; ?>
                                        ">
                                            <h4 class="card-title"><?php echo e(\App\Models\Alliance::find($fixture->team_1_id)->name); ?> VS <?php echo e($fixture->team_2); ?></h4>
                                            <h6 class="card-subtitle mb-0"> <?php echo e($fixture->location); ?> </h6>
                                        </div>
                                        <?php if($fixture->result && $fixture->outcome): ?>
                                        <div class="col-2">
                                            <h4 class="card-title text-primary"><?php echo e($fixture->outcome); ?></h4>
                                            <h6 class="card-subtitle mb-0"> <?php echo e($fixture->result); ?> </h6>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>  
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\upwork\fms\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>