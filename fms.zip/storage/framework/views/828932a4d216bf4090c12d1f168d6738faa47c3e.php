<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor"><?php echo e($alliance->name); ?></h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                
            </ol>
            <!-- <a href="/" class="btn btn-success d-none d-lg-block m-l-15"> Dashboard</a> -->
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
<div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('pages.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="text-center mb-5">
                    <h4 class="card-title"><?php echo e($alliance->name); ?></h4>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex no-block align-items-center">
                            <div>
                                <h6 class="card-title">Add New Coach</h6>
                            </div>
                        </div>
                        <form class="form" method="post" action="<?php echo e(route('alliance.add.coach', $alliance->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="col-9">
                                    <select name="coach" required class="form-control">
                                        <option value="" selected="" disabled="">Select Coach</option>
                                        <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($coach->id); ?>"><?php echo e($coach->name); ?>

                                            <?php if($coach->alliance): ?>
                                            - <?php echo e($coach->alliance->name); ?>

                                            <?php endif; ?>
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['coach'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-3">
                                    <input class="btn btn-primary btn-block" type="submit" value="Add Coach" />
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-6">
                    <div class="d-flex no-block align-items-center">
                            <div>
                                <h6 class="card-title">Add New Player</h6>
                            </div>
                        </div>
                        <form class="form" method="post" action="<?php echo e(route('alliance.add.player', $alliance->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="col-9">
                                    <select name="player" required class="form-control">
                                        <option value="" selected="" disabled="">Select player</option>
                                        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($player->id); ?>"><?php echo e($player->name); ?> 
                                            <?php if($player->alliance): ?>
                                            - <?php echo e($player->alliance->name); ?>

                                            <?php endif; ?>
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['player'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-3">
                                    <input class="btn btn-primary btn-block" type="submit" value="Add Player" />
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-12">
                        <div class="d-flex no-block align-items-center mt-5">
                            <div>
                                <h4 class="card-title">Coaches</h4>
                            </div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $teamCoaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="card shadow rounded">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-2">
                                                <img class="img img-responsive profile-pic-coach" src="<?php echo e(asset($coach->profile_photo_path)); ?>" />
                                            </div>
                                            <div class="col-10">
                                                <h4 class="card-title"><?php echo e($coach->name); ?></h4>
                                                <h6 class="card-subtitle mb-0"> Coach </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="d-flex no-block align-items-center mt-5">
                            <div>
                                <h4 class="card-title">Players</h4>
                            </div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $teamPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('edit.statistic',$player->id)); ?>" class="fixture-card col-md-4">
                                <div class="card shadow rounded">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-2">
                                                <img class="img img-responsive profile-pic-coach" src="<?php echo e(asset($player->photo)); ?>" />
                                            </div>
                                            <div class="col-10">
                                                <h4 class="card-title"><?php echo e($player->name); ?></h4>
                                                <h6 class="card-subtitle mb-0"> <?php echo e(\App\Models\PlayerPosition::find($player->player_position_id)->name); ?> </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="d-flex no-block align-items-center mt-5">
                            <div>
                                <h4 class="card-title">Statistics</h4>
                            </div>
                        </div>
                        <div class="row">
                            <?php if($mostGoalsScored && $mostGoalsScored->goals_scored>0): ?>
                            <a href="<?php echo e(route('edit.statistic',$mostGoalsScored->player->id)); ?>" class="fixture-card col-md-4">
                                <div class="card shadow rounded">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-2">
                                                <img class="img img-responsive profile-pic-coach" src="<?php echo e(asset($mostGoalsScored->player->photo)); ?>" />
                                            </div>
                                            <div class="col-8">
                                                <h4 class="card-title"><?php echo e($mostGoalsScored->player->name); ?></h4>
                                                <h6 class="card-subtitle mb-0"> Most Goals Scored </h6>
                                            </div>
                                            <div class="col-2">
                                                <h4 class="card-title text-primary"><?php echo e($mostGoalsScored->goals_scored); ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <?php endif; ?>

                            <?php if($mostAssists && $mostAssists->assists>0): ?>
                            <a href="<?php echo e(route('edit.statistic',$mostAssists->player->id)); ?>" class="fixture-card col-md-4">
                                <div class="card shadow rounded">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-2">
                                                <img class="img img-responsive profile-pic-coach" src="<?php echo e(asset($mostAssists->player->photo)); ?>" />
                                            </div>
                                            <div class="col-8">
                                                <h4 class="card-title"><?php echo e($mostAssists->player->name); ?></h4>
                                                <h6 class="card-subtitle mb-0"> Most Assists </h6>
                                            </div>
                                            <div class="col-2">
                                                <h4 class="card-title text-primary"><?php echo e($mostAssists->assists); ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <?php endif; ?>
                            
                            <?php if($mostYellowCards && $mostYellowCards->yellow_cards>0): ?>
                            <a href="<?php echo e(route('edit.statistic',$mostYellowCards->player->id)); ?>" class="fixture-card col-md-4">
                                <div class="card shadow rounded">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-2">
                                                <img class="img img-responsive profile-pic-coach" src="<?php echo e(asset($mostYellowCards->player->photo)); ?>" />
                                            </div>
                                            <div class="col-8">
                                                <h4 class="card-title"><?php echo e($mostYellowCards->player->name); ?></h4>
                                                <h6 class="card-subtitle mb-0"> Most Yellow Cards </h6>
                                            </div>
                                            <div class="col-2">
                                                <h4 class="card-title text-primary"><?php echo e($mostYellowCards->yellow_cards); ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <?php endif; ?>

                            <?php if($mostRedCards && $mostRedCards->red_cards>0): ?>
                            <a href="<?php echo e(route('edit.statistic',$mostRedCards->player->id)); ?>" class="fixture-card col-md-4">
                                <div class="card shadow rounded">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-2">
                                                <img class="img img-responsive profile-pic-coach" src="<?php echo e(asset($mostRedCards->player->photo)); ?>" />
                                            </div>
                                            <div class="col-8">
                                                <h4 class="card-title"><?php echo e($mostRedCards->player->name); ?></h4>
                                                <h6 class="card-subtitle mb-0"> Most Red Cards </h6>
                                            </div>
                                            <div class="col-2">
                                                <h4 class="card-title text-primary"><?php echo e($mostRedCards->red_cards); ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <?php endif; ?>

                            <?php if($leastGoalsConceded && $leastGoalsConceded->goals_conceded>0): ?>
                            <a href="<?php echo e(route('edit.statistic',$leastGoalsConceded->player->id)); ?>" class="fixture-card col-md-4">
                                <div class="card shadow rounded">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-2">
                                                <img class="img img-responsive profile-pic-coach" src="<?php echo e(asset($leastGoalsConceded->player->photo)); ?>" />
                                            </div>
                                            <div class="col-8">
                                                <h4 class="card-title"><?php echo e($leastGoalsConceded->player->name); ?></h4>
                                                <h6 class="card-subtitle mb-0"> Least Goals Conceded </h6>
                                            </div>
                                            <div class="col-2">
                                                <h4 class="card-title text-primary"><?php echo e($leastGoalsConceded->goals_conceded); ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\upwork\fms\resources\views/admin/alliances/show_alliance.blade.php ENDPATH**/ ?>