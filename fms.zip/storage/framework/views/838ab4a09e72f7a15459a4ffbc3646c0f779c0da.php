

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 d-flex align-items-center">
    <div class="d-flex justify-content-center  col-12 ">
        <div class="col-12 col-sm-9 col-md-6 col-lg-5 col-xl-4 col-xxl-3 border " style="border-radius: 13px;">

            <div class="col-12 d-flex justify-content-center mt-3">
                <a href="" class="navbar-brand">
                   <!-- <img src="<?php echo e(asset('images/main/logo-icon.png')); ?>" alt="logo" class="dark-logo">-->

                    <span class="logo-part">
                        <img src="<?php echo e(asset('images/main/login-logo.png')); ?>" alt="logo" class="dark-logo">
                    </span>
                </a>
            </div>

            <div class="text-center ">
                <h2><b><?php echo e(__('Login')); ?></b></h2>
            </div>

            <form method="POST" action="<?php echo e(route('login')); ?>" class="row g-3 p-3">
                <?php echo csrf_field(); ?>
                <div class="col-12">
                    <label for="email" class="form-label"><?php echo e(__('Email Address')); ?></label>
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12">
                    <label for="inputPassword4" class="form-label"><?php echo e(__('Password')); ?></label>
                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="col-12 ">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                        <label class="form-check-label" for="remember">
                            <?php echo e(__('Remember Me')); ?>

                        </label>
                    </div>
                </div>

                <div class=" col-11 d-grid gap-2 mx-auto">
                    <button class="btn btn-primary" type="submit"> <?php echo e(__('Login')); ?></button>

                </div>

               

            </form>

        </div>

    </div>



</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8\fms\resources\views/auth/login.blade.php ENDPATH**/ ?>