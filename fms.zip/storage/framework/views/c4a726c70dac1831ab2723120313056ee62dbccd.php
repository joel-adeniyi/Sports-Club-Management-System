

<?php $__env->startSection('content'); ?>

<div class="row page-titles">
    <div class="col-md-5 align-self-center">

    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">Team Category</li>
                
            </ol>
         
        </div>
    </div>
    <div class="d-flex justify-content-end col-12">
           
            <a href="<?php echo e(route('new.team')); ?>" class="btn btn-primary d-none d-lg-block m-l-15"> Add New Team Category</a>
        </div>
</div>

<!--  Page Content -->

<div class="row">
<div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Team Category</h4>
                        <p>In this section, the category for teams are created. Two default categories have been chosen.</p>
                <p><b>First</b> are for players and coaches who are first choice in their team during match selection.</p>
                <p><b>Reserve</b> are for players and coaches who are the backup choice for their team during matches.</p>
                    </div>
                </div>
                <?php echo $__env->make('pages.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th witdh="1%">#</th>
                                <th>Name</th>
                                <th width="20%">Actions</th>
                            </tr>
                        </thead>
                            <tbody><?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $teams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($teams->name); ?></td>
                                <td>
                                <a href="<?php echo e(route('edit.team',$teams->id)); ?>" class="btn btn-primary">Edit</a>
                                <a href="<?php echo e(route('delete.team',$teams->id)); ?>" class="btn btn-danger" id="delete" onclick="return confirm('Are you sure you want to delete this team?');"> Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8\fms\resources\views/admin/teams/view_team.blade.php ENDPATH**/ ?>