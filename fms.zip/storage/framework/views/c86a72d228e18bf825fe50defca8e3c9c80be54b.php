<?php $__env->startSection('content'); ?>
<div class="min-vh-100 d-flex align-items-center">
    <div class="d-flex justify-content-center  col-12 ">
        <div class="col-12 col-sm-9 col-md-6 col-lg-5 col-xl-4 col-xxl-3 border " style="border-radius: 13px;">

            <div class="col-12 d-flex justify-content-center mt-3">
                <a href="http://localhost/upwork/fms/public" class="navbar-brand">
                    <img src="<?php echo e(asset('images/adminpanel/logo-icon.png')); ?>" alt="homepage" class="dark-logo">

                    <span class="logo-part">
                        <img src="<?php echo e(asset('images/adminpanel/logo-text.png')); ?>" alt="homepage" class="dark-logo">
                    </span>
                </a>
            </div>

            <div class="text-center ">
                <h3><b><?php echo e(__('Reset Password')); ?></b></h3>
            </div>


            <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('password.email')); ?>" class="row g-3 p-3">
                <?php echo csrf_field(); ?>
                <div class="col-12">
                    <label for="email" class="form-label"><?php echo e(__('Email Address')); ?></label>
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                </div>

                <div class=" col-11 d-grid gap-2 mx-auto mb-5">
                    <button class="btn btn-primary" type="submit"> <?php echo e(__('Send Password Reset Link')); ?></button>

                </div>



            </form>

        </div>

    </div>



</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8\fms\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>