<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> Football Management System</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <meta name="robots" content="noindex,nofollow">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/adminpanel/favicon.png')); ?>">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>

<body class="skin-default-dark fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Football Management System</p>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="app">
        <div id="main-wrapper">
            <!-- ============================================================== -->
            <!-- Topbar header - style you can find in pages.scss -->
            <!-- ============================================================== -->
            <header class="topbar">
                <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <div class="navbar-header">
                        <a class="navbar-brand" hrefhref="<?php echo e(url('/')); ?>">
                            <!-- Logo icon --><b>
                                <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                                <!-- Dark Logo icon -->
                                <img src="<?php echo e(asset('images/adminpanel/logo-icon.png')); ?>" alt="homepage" class="dark-logo" />
                                <!-- Light Logo icon -->
                                <img src="<?php echo e(asset('images/adminpanel/logo-light-icon.png')); ?>" alt="homepage" class="light-logo" />
                            </b>
                            <!--End Logo icon -->
                            <!-- Logo text --><span>
                                <!-- dark Logo text -->
                                <img src="<?php echo e(asset('images/adminpanel/logo-text.png')); ?>" alt="homepage" class="dark-logo" />
                                <!-- Light Logo text -->
                                <img src="<?php echo e(asset('images/adminpanel/logo-light-text.png')); ?>" class="light-logo" alt="homepage" /></span>
                        </a>
                    </div>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <div class="navbar-collapse">
                        <!-- ============================================================== -->
                        <!-- toggle and nav items -->
                        <!-- ============================================================== -->
                        <ul class="navbar-nav mr-auto">
                            <!-- This is  -->
                            <li class="nav-item hidden-sm-up"> <a class="nav-link nav-toggler waves-effect waves-light"
                                    href="javascript:void(0)"><i class="ti-menu"></i></a></li>
                            <!-- ============================================================== -->
                            <!-- Search -->
                            <!-- ============================================================== -->
                            
                        </ul>
                        <ul class="navbar-nav my-lg-0">
                         
                        </ul>
                    </div>
                </nav>
            </header>
            <!-- ============================================================== -->
            <!-- End Topbar header -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Left Sidebar - style you can find in sidebar.scss  -->
            <!-- ============================================================== -->
            <aside class="left-sidebar">
                <div class="d-flex no-block nav-text-box align-items-center">
                    
                    <a class="waves-effect waves-dark ml-auto hidden-sm-down" href="javascript:void(0)"><i
                            class="ti-menu"></i></a>
                    <a class="nav-toggler waves-effect waves-dark ml-auto hidden-sm-up" href="javascript:void(0)"><i
                            class="ti-menu ti-close"></i></a>
                </div>
                <!-- Sidebar scroll-->
                <div class="scroll-sidebar">
                    <!-- Sidebar navigation-->
                    <nav class="sidebar-nav">
                        <ul id="sidebarnav">
                            <li> <a class="waves-effect waves-dark" href="<?php echo e(url('/')); ?>" aria-expanded="false"><i
                                        class="fa fa-tachometer"></i><span class="hide-menu">Home</span></a></li>
                            <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="fa fa-user-circle-o"></i><span class="hide-menu">Profile Management</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="<?php echo e(route('change.pass')); ?>">Change Password <i class="fa fa-circle text-success"></i></a></li>
                                </ul>
                            </li>
                            <!--<li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="fa fa-address-book"></i><span class="hide-menu">Registration Setup</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="<?php echo e(route('view.team')); ?>">Team Setup <i class="fa fa-circle text-success"></i></a></li>
                                    <li><a href="<?php echo e(route('view.squad')); ?>">Squad Setup <i class="fa fa-circle text-success"></i></a></li>
                                    <li><a href="<?php echo e(route('view.contract')); ?>">Contract Type Setup <i class="fa fa-circle text-success"></i></a></li>
                                </ul>
                            </li>-->
                            <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="fa fa-user"></i><span class="hide-menu">Coach Management</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <?php if(Auth::user()->role==1): ?>
                                    <li><a href="<?php echo e(route('new.coach')); ?>">Coach Registration <i class="fa fa-circle text-success"></i></a></li>
                                    <?php endif; ?>
                                    <li><a href="<?php echo e(route('view.coach')); ?>">View Coaches <i class="fa fa-circle text-success"></i></a></li>
                                </ul>
                            </li>
                            <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="fa fa-male"></i><span class="hide-menu">Player Management</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <?php if(Auth::user()->role==1): ?>
                                    <li><a href="<?php echo e(route('new.player')); ?>">Player Registration <i class="fa fa-circle text-success"></i></a></li>
                                    <?php endif; ?>
                                    <li><a href="<?php echo e(route('view.player')); ?>">View Players <i class="fa fa-circle text-success"></i></a></li>
                                </ul>
                            </li>
                            <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="fa fa-users"></i><span class="hide-menu">Teams</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="<?php echo e(route('alliance.create')); ?>">Create Team <i class="fa fa-circle text-success"></i></a></li>
                                    <li><a href="<?php echo e(route('alliance.index')); ?>">View Teams <i class="fa fa-circle text-success"></i></a></li>
                                </ul>
                            </li>
                            
                            <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="fa fa-globe"></i><span class="hide-menu">Fixtures</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="<?php echo e(route('fixture.create')); ?>">Add Fixture <i class="fa fa-circle text-success"></i></a></li>
                                    <li><a href="<?php echo e(route('fixture.index')); ?>">View Fixtures <i class="fa fa-circle text-success"></i></a></li>
                                </ul>
                            </li>
                            <!-- <li> <a class="waves-effect waves-dark" href="table-basic.html" aria-expanded="false"><i
                                        class="fa fa-table"></i><span class="hide-menu"></span>Tables</a></li>
                            <li> <a class="waves-effect waves-dark" href="icon-fontawesome.html" aria-expanded="false"><i
                                        class="fa fa-smile-o"></i><span class="hide-menu"></span>Icon</a></li>
                            <li> <a class="waves-effect waves-dark" href="map-google.html" aria-expanded="false"><i
                                        class="fa fa-globe"></i><span class="hide-menu"></span>Map</a></li>
                            <li> <a class="waves-effect waves-dark" href="pages-blank.html" aria-expanded="false"><i
                                        class="fa fa-bookmark-o"></i><span class="hide-menu"></span>Blank</a></li>
                            <li> <a class="waves-effect waves-dark" href="pages-error-404.html" aria-expanded="false"><i
                                        class="fa fa-question-circle"></i><span class="hide-menu"></span>404</a></li> -->

                            <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="fa fa-globe"></i><span class="hide-menu">Generate Reports</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="<?php echo e(route('generate.statistic')); ?>">Statistical Reports <i class="fa fa-circle text-success"></i></a></li>
                                    
                                </ul>
                            </li>
                            <div class="text-center m-t-30">
                                <a class="btn waves-effect waves-light btn-success hidden-md-down" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </ul>
                    </nav>
                    <!-- End Sidebar navigation -->
                </div>
                <!-- End Sidebar scroll-->
            </aside>
            <!-- ============================================================== -->
            <!-- End Left Sidebar - style you can find in sidebar.scss  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Page wrapper  -->
            <!-- ============================================================== -->
            <div class="page-wrapper">
                <!-- ============================================================== -->
                <!-- Container fluid  -->
                <!-- ============================================================== -->
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!-- ============================================================== -->
                <!-- End Container fluid  -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Page wrapper  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer">
            Football Management System
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo e(asset('vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo e(asset('vendor/popper/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo e(asset('js/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <!--Wave Effects -->
    <script src="<?php echo e(asset('js/waves.js')); ?>"></script>
    <!--Menu sidebar -->
    <script src="<?php echo e(asset('js/sidebarmenu.js')); ?>"></script>
    <!--stickey kit -->
    <script src="<?php echo e(asset('vendor/sticky-kit-master/dist/sticky-kit.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/sparkline/jquery.sparkline.min.js')); ?>"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\upwork\fms\resources\views/layouts/admin_.blade.php ENDPATH**/ ?>