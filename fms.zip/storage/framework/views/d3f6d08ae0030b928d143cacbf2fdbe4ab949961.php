<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor">Fixtures</h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">Fixtures</li>
            </ol>
          
		</div>
    </div>
    <div class="col-12 d-flex justify-content-end">
    <a href="<?php echo e(route('fixture.create')); ?>" class="btn btn-primary  "> Add Fixture</a>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
<div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Fixtures</h4>
                    </div>
                </div>
                <?php echo $__env->make('pages.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Team 1</th>
                                <th>Team 2</th>
                                <th>Location</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                            <tbody><?php $__currentLoopData = $fixtures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fixture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
								<td><?php echo e(\App\Models\Alliance::find($fixture->team_1_id)->name); ?></td>
								<td><?php echo e($fixture->team_2); ?></td>
                                <td><?php echo e($fixture->location); ?></td>
                                <td><?php echo e($fixture->date); ?></td>
								<td style="white-space: nowrap">
                                    <?php if($fixture->score_added==0): ?>
                                        <a href="<?php echo e(route('add.scores', ['fixture' => $fixture->id])); ?>" class="btn btn-warning">Add Scores</a>
                                    <?php else: ?>
                                        <button class="btn btn-warning" disabled>Score Added</button>
                                    <?php endif; ?>
                                    <?php if($fixture->result && $fixture->outcome): ?>
                                    <a href="<?php echo e(route('fixture.show', $fixture->id)); ?>" class="btn btn-info">Results</a>
                                    <?php endif; ?>
									<a href="<?php echo e(route('fixture.edit', $fixture->id)); ?>" class="btn btn-primary">Edit</a>
                                    <form action="<?php echo e(route('fixture.destroy', ['fixture' => $fixture->id])); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this fixture?');">Delete</button>
                                    </form>
                                </td>
							</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\upwork\fms\resources\views/admin/fixtures/view_fixtures.blade.php ENDPATH**/ ?>