<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h4 class="text-themecolor">Players</h4>
    </div>
    <div class="col-md-7 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">Players</li>
            </ol>
            <?php if(Auth::user()->role==1): ?>
            <a href="<?php echo e(route('new.player')); ?>" class="btn btn-primary d-none d-lg-block m-l-15"> Add New Player</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Start Page Content -->
<!-- ============================================================== -->
<div class="row">
<div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex no-block align-items-center">
                    <div>
                        <h4 class="card-title">Players</h4>
                    </div>
                </div>
                <?php echo $__env->make('pages.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Name</th>
                                <th>Team</th>
                                <th>Squad</th>
                                <th>Contract</th>
                                <th>Player Position</th>
                                <th>Contact</th>
                                <th>DOB</th>
                                <th>Address</th>
                                <?php if(Auth::user()->role==1): ?>
                                <th>Actions</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                            <tbody><?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
								<td><img class="img profile-pic-coach" src="<?php echo e(asset($player->photo)); ?>" /></td>
								<td><?php echo e($player->name); ?></td>
                                <td style="white-space: nowrap"><?php echo e(\App\Models\Teams::find($player->team_id)->name); ?> </td>
                                <td><?php echo e(\App\Models\Squad::find($player->squad_id)->name); ?> </td>
                                <td><?php echo e(\App\Models\Contracts::find($player->contract_id)->type); ?> </td>
                                <td><?php echo e(\App\Models\PlayerPosition::find($player->player_position_id)->name); ?> </td>
                                <td style="white-space: nowrap"><?php echo e($player->phone); ?></td>
                                <td style="white-space: nowrap"><?php echo e($player->dob); ?></td>
                                <td><?php echo e($player->address); ?></td>
                                <?php if(Auth::user()->role==1): ?>
                                <td style="white-space: nowrap">
									<a href="<?php echo e(route('edit.statistic',$player->id)); ?>" class="btn btn-warning">Statistics</a>
									<a href="<?php echo e(route('edit.player',$player->id)); ?>" class="btn btn-primary">Edit</a>
									<a href="<?php echo e(route('delete.player',$player->id)); ?>" class="btn btn-danger" id="delete" onclick="return confirm('Are you sure you want to delete this player?');"> Delete</a>
								</td>
                                <?php endif; ?>
							</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\upwork\fms\resources\views/admin/players/view_players.blade.php ENDPATH**/ ?>